// slideshow
$("#slideshow > div:gt(0)").hide();

setInterval(function() {
  $('#slideshow > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#slideshow');
}, 10000);

//video
var player = videojs('player');
var playBtn = $('#play');
var rewindBtn = $('#rewind');

player.on('ready', function() {
    //play btn
    playBtn.click(function(){

if(!player.paused()){
    player.pause();
} else{
    player.play();
}
    });
});

// rewind
rewindBtn.click(function(){
    var time = player.currentTime();
    player.currentTime(time - 2);
}
)

player.on('ended', function(){
    $("body".css({background:"green"}));
});
